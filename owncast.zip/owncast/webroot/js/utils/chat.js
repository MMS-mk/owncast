import {
  CHAT_INITIAL_PLACEHOLDER_TEXT,
  CHAT_PLACEHOLDER_TEXT,
  CHAT_PLACEHOLDER_OFFLINE,
} from './constants.js';

// https://stackoverflow.com/a/46902361
export function getCaretPosition(node) {
  var range = window.getSelection().getRangeAt(0),
    preCaretRange = range.cloneRange(),
    caretPosition,
    tmp = document.createElement('div');

  preCaretRange.selectNodeContents(node);
  preCaretRange.setEnd(range.endContainer, range.endOffset);
  tmp.appendChild(preCaretRange.cloneContents());
  caretPosition = tmp.innerHTML.length;
  return caretPosition;
}

export function setCaretPosition(editableDiv, position) {
  var range = document.createRange();
  var sel = window.getSelection();
  range.selectNode(editableDiv);
  range.setStart(editableDiv.childNodes[0], position);
  range.collapse(true);

  sel.removeAllRanges();
  sel.addRange(range);
}

export function generatePlaceholderText(isEnabled, hasSentFirstChatMessage) {
  if (isEnabled) {
    return hasSentFirstChatMessage
      ? CHAT_PLACEHOLDER_TEXT
      : CHAT_INITIAL_PLACEHOLDER_TEXT;
  }
  return CHAT_PLACEHOLDER_OFFLINE;
}

export function extraUserNamesFromMessageHistory(messages) {
  const list = [];
  if (messages) {
    messages.forEach(function (message) {
      if (!list.includes(message.user.displayName)) {
        list.push(message.user.displayName);
      }
    });
  }
  return list;
}

export function convertToText(str = '') {
  let value = String(str);
  value = value.replace(/&nbsp;/gi, ' ');
  value = value.replace(/&amp;/gi, '&');
  value = value.replace(/<br>/gi, '\n');
  value = value.replace(/<div>/gi, '\n');
  value = value.replace(/<p>/gi, '\n');
  value = value.replace(/\u200C{2}/gi, '');
  value = value
    .split('\n')
    .map((line = '') => {
      return line.trim();
    })
    .join('\n');
  value = value.replace(/\n\n+/g, '\n\n');
  value = value.replace(/[ ]+/g, ' ');
  value = value.trim();
  return value;
}

export function convertOnPaste(event = { preventDefault() {} }, emojiList) {
  event.preventDefault();
  let value = '';
  const hasEventClipboard = !!(
    event.clipboardData &&
    typeof event.clipboardData === 'object' &&
    typeof event.clipboardData.getData === 'function'
  );
  if (hasEventClipboard) {
    value = event.clipboardData.getData('text/plain');
  }

  const textarea = document.createElement('textarea');
  textarea.innerHTML = value;
  value = textarea.innerText;
  value = convertToText(value);
  const HTML = emojify(value, emojiList);
  if (typeof document.execCommand === 'function') {
    document.execCommand('insertHTML', false, HTML);
  }
}

export function createEmojiMarkup(data, isCustom) {
  const emojiUrl = isCustom ? data.emoji : data.url;
  const emojiName = (
    isCustom
      ? data.name
      : data.url.split('\\').pop().split('/').pop().split('.').shift()
  ).toLowerCase();
  return (
    '<img class="emoji" alt=":‌‌' +
    emojiName +
    '‌‌:" title=":‌‌' +
    emojiName +
    '‌‌:" src="' +
    emojiUrl +
    '"/>'
  );
}

export function trimNbsp(html) {
  return html.replace(/^(?:&nbsp;|\s)+|(?:&nbsp;|\s)+$/gi, '');
}

export function emojify(HTML, emojiList) {
  const textValue = convertToText(HTML);

  for (var lastPos = textValue.length; lastPos >= 0; lastPos--) {
    const endPos = textValue.lastIndexOf(':', lastPos);
    if (endPos <= 0) {
      break;
    }
    const startPos = textValue.lastIndexOf(':', endPos - 1);
    if (startPos === -1) {
      break;
    }
    const typedEmoji = textValue.substring(startPos + 1, endPos).trim();
    const emojiIndex = emojiList.findIndex(function (emojiItem) {
      return emojiItem.name.toLowerCase() === typedEmoji.toLowerCase();
    });

    if (emojiIndex != -1) {
      const emojiImgElement = createEmojiMarkup(emojiList[emojiIndex], true);
      HTML = HTML.replace(':' + typedEmoji + ':', emojiImgElement);
    }
  }
  return HTML;
}
