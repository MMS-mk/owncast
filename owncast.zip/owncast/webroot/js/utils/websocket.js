import { URL_WEBSOCKET } from './constants.js';
export const SOCKET_MESSAGE_TYPES = {
  CHAT: 'CHAT',
  PING: 'PING',
  NAME_CHANGE: 'NAME_CHANGE',
  PONG: 'PONG',
  SYSTEM: 'SYSTEM',
  USER_JOINED: 'USER_JOINED',
  CHAT_ACTION: 'CHAT_ACTION',
  CONNECTED_USER_INFO: 'CONNECTED_USER_INFO',
  ERROR_USER_DISABLED: 'ERROR_USER_DISABLED',
  ERROR_NEEDS_REGISTRATION: 'ERROR_NEEDS_REGISTRATION',
  ERROR_MAX_CONNECTIONS_EXCEEDED: 'ERROR_MAX_CONNECTIONS_EXCEEDED',
};

export const CALLBACKS = {
  RAW_WEBSOCKET_MESSAGE_RECEIVED: 'rawWebsocketMessageReceived',
  WEBSOCKET_CONNECTED: 'websocketConnected',
};

const TIMER_WEBSOCKET_RECONNECT = 5000; // ms

export default class Websocket {
  constructor(accessToken) {
    this.websocket = null;
    this.websocketReconnectTimer = null;
    this.accessToken = accessToken;

    this.websocketConnectedListeners = [];
    this.websocketDisconnectListeners = [];
    this.rawMessageListeners = [];

    this.send = this.send.bind(this);
    this.createAndConnect = this.createAndConnect.bind(this);
    this.scheduleReconnect = this.scheduleReconnect.bind(this);
    this.shutdown = this.shutdown.bind(this);

    this.isShutdown = false;

    this.createAndConnect();
  }

  createAndConnect() {
    const url = new URL(URL_WEBSOCKET);
    url.searchParams.append('accessToken', this.accessToken);

    const ws = new WebSocket(url.toString());
    ws.onopen = this.onOpen.bind(this);
    ws.onclose = this.onClose.bind(this);
    ws.onerror = this.onError.bind(this);
    ws.onmessage = this.onMessage.bind(this);

    this.websocket = ws;
  }

  addListener(type, callback) {
    if (type == CALLBACKS.WEBSOCKET_CONNECTED) {
      this.websocketConnectedListeners.push(callback);
    } else if (type == CALLBACKS.WEBSOCKET_DISCONNECTED) {
      this.websocketDisconnectListeners.push(callback);
    } else if (type == CALLBACKS.RAW_WEBSOCKET_MESSAGE_RECEIVED) {
      this.rawMessageListeners.push(callback);
    }
  }

  send(message) {
    if (!message.type || !SOCKET_MESSAGE_TYPES[message.type]) {
      console.warn(
        `Грешка: Сокетот неможе да се закачи: "${message.type}" sent.`
      );
    }

    const messageJSON = JSON.stringify(message);
    this.websocket.send(messageJSON);
  }

  shutdown() {
    this.isShutdown = true;
    this.websocket.close();
  }

  notifyWebsocketConnectedListeners(message) {
    this.websocketConnectedListeners.forEach(function (callback) {
      callback(message);
    });
  }

  notifyWebsocketDisconnectedListeners(message) {
    this.websocketDisconnectListeners.forEach(function (callback) {
      callback(message);
    });
  }

  notifyRawMessageListeners(message) {
    this.rawMessageListeners.forEach(function (callback) {
      callback(message);
    });
  }

  onOpen(e) {
    if (this.websocketReconnectTimer) {
      clearTimeout(this.websocketReconnectTimer);
    }

    this.notifyWebsocketConnectedListeners();
  }

  onClose(e) {
    this.websocket = null;
    this.notifyWebsocketDisconnectedListeners();
    this.handleNetworkingError('Сокетот е затворен.');
    if (!this.isShutdown) {
      this.scheduleReconnect();
    }
  }

  onError(e) {
    this.handleNetworkingError(`Грешка во сокетот: ${JSON.parse(e)}`);
    this.websocket.close();
    if (!this.isShutdown) {
      this.scheduleReconnect();
    }
  }

  scheduleReconnect() {
    this.websocketReconnectTimer = setTimeout(
      this.createAndConnect,
      TIMER_WEBSOCKET_RECONNECT
    );
  }

  onMessage(e) {
    var messages = e.data.split('\n');
    for (var i = 0; i < messages.length; i++) {
      try {
        var model = JSON.parse(messages[i]);
      } catch (e) {
        console.error(e, e.data);
        return;
      }

      if (!model.type) {
        console.error('No type provided', model);
        return;
      }
      if (model.type === SOCKET_MESSAGE_TYPES.PING) {
        this.sendPong();
        return;
      }
      this.notifyRawMessageListeners(model);
    }
  }

  sendPong() {
    const pong = { type: SOCKET_MESSAGE_TYPES.PONG };
    this.send(pong);
  }

  handleNetworkingError(error) {
    console.error(
      `Чатот се исклучи или не работи за тебе. Ова е затоа што си ифрлен од чатот или има грешка во серверот при конекцијата со него.`
    );
  }
}
