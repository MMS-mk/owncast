import { h, Component, createRef } from '/js/web_modules/preact.js';
export function replaceCaret(el) {
  const target = document.createTextNode('');
  el.appendChild(target);
  const isTargetFocused = document.activeElement === el;
  if (target !== null && target.nodeValue !== null && isTargetFocused) {
    var sel = window.getSelection();
    if (sel !== null) {
      var range = document.createRange();
      range.setStart(target, target.nodeValue.length);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    if (el) el.focus();
  }
}

function normalizeHtml(str) {
  return str && str.replace(/&nbsp;|\u202F|\u00A0/g, ' ');
}

export default class ContentEditable extends Component {
  constructor(props) {
    super(props);
    this.el = createRef();
    this.lastHtml = '';
    this.emitChange = this.emitChange.bind(this);
    this.getDOMElement = this.getDOMElement.bind(this);
  }

  shouldComponentUpdate(nextProps) {
    const { props } = this;
    const el = this.getDOMElement();
    if (!el) return true;
    if (
      normalizeHtml(nextProps.html) !== normalizeHtml(el.innerHTML)
    ) {
      return true;
    }
    return props.disabled !== nextProps.disabled ||
      props.tagName !== nextProps.tagName ||
      props.className !== nextProps.className ||
      props.innerRef !== nextProps.innerRef;
  }

  componentDidUpdate() {
    const el = this.getDOMElement();
    if (!el) return;
    if (this.props.html !== el.innerHTML) {
      el.innerHTML = this.props.html;
    }
    this.lastHtml = this.props.html;
    replaceCaret(el);
  }

  getDOMElement() {
    return (this.props.innerRef && typeof this.props.innerRef !== 'function' ? this.props.innerRef : this.el).current;
  }


  emitChange(originalEvt) {
    const el = this.getDOMElement();
    if (!el) return;

    const html = el.innerHTML;
    if (this.props.onChange && html !== this.lastHtml) {
      const evt = Object.assign({}, originalEvt, {
        target: {
          value: html
        }
      });
      this.props.onChange(evt);
    }
    this.lastHtml = html;
  }

  render(props) {
    const { html, innerRef } = props;
    return h(
      'div',
      {
        ...props,
        ref: typeof innerRef === 'function' ? (current) => {
          innerRef(current)
          this.el.current = current
        } : innerRef || this.el,
        onInput: this.emitChange,
        onFocus: this.props.onFocus || this.emitChange,
        onBlur: this.props.onBlur || this.emitChange,
        onKeyup: this.props.onKeyUp || this.emitChange,
        onKeydown: this.props.onKeyDown || this.emitChange,
        contentEditable: !this.props.disabled,
        dangerouslySetInnerHTML: { __html: html },
      },
      this.props.children,
    );
  }
}
